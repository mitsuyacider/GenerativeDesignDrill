// 初期化の関数
function setup() {
	createCanvas(windowWidth, windowHeight);
	background(0);	
}

function draw() {
	fill(255);

	noStroke();
	for (let i = 0; i < height; i++) {
		rect(0, i * (5 + 10), width, 5);
	}
	
	noFill();
	stroke(255);
	strokeWeight(5);
	const num = 20;
	const size = 30;
	for (let i = num; i > 1; i--) {
		ellipse(width / 2, height / 2, i * size, i * size);
	}	
}